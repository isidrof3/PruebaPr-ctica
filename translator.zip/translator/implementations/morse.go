package implementations

type Morse struct {
	//Type string

}

func (m *Morse) Translate(req interface{}) (interface{}, error) {

	var textoTraducido string

	return textoTraducido, nil
}
