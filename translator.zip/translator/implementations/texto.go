package implementations

type Texto struct {
	texto string
}

func (t *Texto) Translate(req interface{}) (interface{}, error) {

	var textoTraducido string

	return textoTraducido, nil
}
