package implementations

type Binary struct {
	//Type string

}

func (b *Binary) Translate(req interface{}) (interface{}, error) {

	var textoTraducido string

	return textoTraducido, nil
}
